---
name: Bug report
about: Create a report to help us improve
title: ''
labels: new
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is (about one sentence long).

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

The error happens (sometimes/every time).

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Desktop (please complete the following information):**
 - OS: [e.g., Windows 10, Ubuntu 20.04]
 - BleachBit version [e.g., 4.2.0]

**Additional context**
Add any other context about the problem here.
