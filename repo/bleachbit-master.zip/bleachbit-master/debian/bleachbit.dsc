Format: 1.0
Source: bleachbit
Binary: bleachbit
Architecture: all
Version: 6.0.3-0
Maintainer: Andrew Ziem <andrew@bleachbit.org>
Homepage: https://www.bleachbit.org
Standards-Version: 3.7.3
Build-Depends: debhelper (>= 4)
Build-Depends-Indep: python3, gettext, desktop-file-utils
Files:
 28528d402964e74dc2da424a9279827e 24376 bleachbit_6.0.3.orig.tar.gz
 64514267a04d925d9a4e4d86.0.38b07 1150 bleachbit_6.0.3-1.diff.gz


